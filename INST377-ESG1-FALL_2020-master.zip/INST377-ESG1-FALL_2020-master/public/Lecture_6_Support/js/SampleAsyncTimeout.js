setTimeout(function callAfterTimeout(){
	console.log("At least five seconds have passed");
},5000);

console.log("This is a test");