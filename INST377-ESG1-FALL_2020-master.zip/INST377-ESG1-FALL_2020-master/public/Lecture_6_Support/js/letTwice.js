let burger = "Well done";
let burger = "Rare";