const obj = {name:"Bill", name:"Dana"}
// The second 'name' overwrites the first one.

console.log(obj.name); 