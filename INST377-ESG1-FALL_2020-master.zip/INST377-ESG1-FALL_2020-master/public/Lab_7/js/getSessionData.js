// Get saved data from sessionStorage
let title = ""; // Your code here
let lat_max = "";
let lat_min = "";
let lon_max = "";
let lon_min = "";

// Your code here
// Set the corresponding <p> elements in the GetSessionData.html page with the values from above
