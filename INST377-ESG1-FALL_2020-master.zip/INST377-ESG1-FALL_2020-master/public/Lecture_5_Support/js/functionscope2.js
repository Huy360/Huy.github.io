// second.js
let name = 'Zaptec';
function greeting() {
  let name2 = 'Bill';
  alert('Our company is called ' + name + '.');
}