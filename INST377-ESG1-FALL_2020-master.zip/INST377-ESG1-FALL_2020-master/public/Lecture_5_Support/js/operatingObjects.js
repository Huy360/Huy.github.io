// Define an object
const objPerson= {name:"Bill"};
// Again, object contents are not constant, but the object type is
// Access by the key
console.log(objPerson.name);
// Manipulate object by setting values via key
objPerson.name = "Betty";
console.log(objPerson.name);

// document.getElementByID is therefore a Function stored on an object Key