// Difference between === and ==
//
// === does a type check as well
10 == '10'; // This normall would be false, but in Javascript it is true 
console.log(10 == '10');

console.log(10==='10'); // Is the correct form of this statement
console.log(10===10); // Is the correct form of this statement
!==