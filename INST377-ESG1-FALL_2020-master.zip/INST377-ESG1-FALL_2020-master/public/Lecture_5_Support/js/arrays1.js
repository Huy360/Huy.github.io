const arr = []; // Array contents are not counted as constant but the array type is.

const arr1 = [1,2,3,4,5];

console.log(arr1[3]);

// There are built-in function to manipulate arrays
console.log(arr1);
arr1.push(6);
console.log(arr1);


const strArr1 = ["Nala", "Geno","Crosby"];
console.log(strArr1);
strArr1.push("Ethel");
console.log(strArr1);
strArr1.pop();
console.log(strArr1);
