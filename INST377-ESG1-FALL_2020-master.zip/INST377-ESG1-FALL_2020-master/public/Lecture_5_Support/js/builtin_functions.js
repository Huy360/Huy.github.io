// Text
let myText = 'I am a string';
let newString = myText.replace('string', 'sausage');
console.log(newString);

// Array
let myArray = ['I', 'love', 'chocolate', 'frogs'];
let madeAString = myArray.join(' ');
console.log(madeAString);

// Math
let myNumber = Math.random();
console.log(myNumber);
// the random() function generates a random number between
// 0 and up to but not including 1, and returns that number