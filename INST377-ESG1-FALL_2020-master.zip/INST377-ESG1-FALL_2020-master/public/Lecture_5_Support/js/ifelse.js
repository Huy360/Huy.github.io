const myNumber = 24;
const myNumString = 24;

if(myNumber === myNumString){
    console.log('Number is 24');
}
else{
    // a single quote used as an apostrophe is a special character, it needs to be escaped
    console.log('Those types don\'t match');
}