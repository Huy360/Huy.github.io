// first.js

function greeting() {
  let name = 'Chris';
  alert('Hello ' + name + ': welcome to our company.');
}