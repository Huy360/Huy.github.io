let count = 0;
let text = '';
while (count < 10){
    text += "The number is " + count + '\n';
    count++;
}

console.log('count going foward: ', count);
console.log('text: ', text);