document.querySelector('html').style.backgroundColor = 'red';
// include the above as a script to test if js is being included correctly
//   this will turn the background red if it is included correctly