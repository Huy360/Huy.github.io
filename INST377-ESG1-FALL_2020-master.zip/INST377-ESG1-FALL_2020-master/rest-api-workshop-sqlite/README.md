Files based on
 - https://www.youtube.com/watch?v=o3ka5fYysBM 
    - Notes: 
        - Webstorm (JetBrains) and VSCode are very similar
        - Insomnia and Postman are very similar. I've used Postman before, this was the first time with Insomnia.
        - npm install mongoose
 - https://developerhowto.com/2018/12/29/build-a-rest-api-with-node-js-and-express-js/ 
    - SQLLite version instead of Mongodb
    - npm install sqlite3
    - npm install md5


npm install express
npm install mongoose
npm install nodemon -D
npm install body-parser
